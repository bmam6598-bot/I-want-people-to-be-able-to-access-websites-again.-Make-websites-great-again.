(function(){
  // Populate updated date (fixed)
  const span = document.querySelector('#updated span');
  span.textContent = 'September 1, 2024';

  // Print behaviour
  document.getElementById('printBtn').addEventListener('click', () => {
    window.print();
  });


})();
document.getElementById('year').textContent = new Date().getFullYear();

/* Small enhancement: keyboard focus outlines for accessibility */
(function(){
  const body = document.body;
  function handleFirstTab(e){
    if(e.key === 'Tab'){
      body.classList.add('user-is-tabbing');
      window.removeEventListener('keydown', handleFirstTab);
    }
  }
  window.addEventListener('keydown', handleFirstTab);
})();

/* Simple client-side Archive: stores submissions in localStorage and renders them */
const STORAGE_KEY = 'dpsdiga_user_archive_v1';
const form = document.getElementById('archive-form');
const itemsList = document.getElementById('items');
const clearBtn = document.getElementById('clear-uploads');
const exportBtn = document.getElementById('export-json');
const copyBtn = document.getElementById('copy-json');
const importFile = document.getElementById('import-file');

function loadItems(){
  try{
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  }catch(e){
    console.error('Failed to parse storage', e);
    return [];
  }
}

function saveItems(items){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
  // trigger storage event for same-tab listeners
  window.dispatchEvent(new Event('storageSync'));
}

function renderItems(){
  const items = loadItems();
  itemsList.innerHTML = '';
  if(items.length === 0){
    itemsList.innerHTML = '<li class="empty">No community submissions yet.</li>';
    return;
  }
  items.forEach((it) => {
    const li = document.createElement('li');
    li.setAttribute('data-id', it.id);
    li.innerHTML = `
      <div class="item-meta">
        <div class="item-title">${escapeHTML(it.title)}</div>
        <div class="item-actions">
          <button class="btn" data-action="edit" data-id="${it.id}">Edit</button>
          <button class="btn" data-action="delete" data-id="${it.id}">Delete</button>
        </div>
      </div>
      <div class="item-desc">${escapeHTML(it.description)}</div>
      ${it.link ? `<a class="item-link" href="${escapeAttr(it.link)}" target="_blank" rel="noopener">Open link</a>` : ''}
      <div class="item-meta"><small class="muted">Added ${new Date(it.created).toLocaleString()}</small></div>
    `;
    itemsList.appendChild(li);
  });
}

/* Escaping helpers */
function escapeHTML(s = ''){
  return String(s).replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
}
function escapeAttr(s = ''){
  return escapeHTML(s).replace(/"/g,'&quot;');
}

/* Form handling */
form.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = form.querySelector('#item-title').value.trim();
  const description = form.querySelector('#item-desc').value.trim();
  const link = form.querySelector('#item-link').value.trim();
  if(!title || !description) return;

  const items = loadItems();
  const newItem = {
    id: 'i' + Date.now(),
    title,
    description,
    link: link || '',
    created: Date.now()
  };
  items.unshift(newItem);
  saveItems(items);
  form.reset();
  renderItems();
});

/* Click handlers for edit/delete */
itemsList.addEventListener('click', (e) => {
  const btn = e.target.closest('button');
  if(!btn) return;
  const id = btn.dataset.id;
  const action = btn.dataset.action;
  if(action === 'delete'){
    const items = loadItems().filter(i => i.id !== id);
    saveItems(items);
    renderItems();
  } else if(action === 'edit'){
    const items = loadItems();
    const item = items.find(i => i.id === id);
    if(!item) return;
    // Populate form for editing: delete original and prefill
    const remaining = items.filter(i => i.id !== id);
    saveItems(remaining);
    form.querySelector('#item-title').value = item.title;
    form.querySelector('#item-desc').value = item.description;
    form.querySelector('#item-link').value = item.link || '';
    renderItems();
    window.scrollTo({top: form.getBoundingClientRect().top + window.scrollY - 20, behavior:'smooth'});
  }
});

/* Clear storage */
clearBtn.addEventListener('click', () => {
  if(confirm('Clear all community submissions stored in this browser?')) {
    localStorage.removeItem(STORAGE_KEY);
    renderItems();
    // notify other tabs
    window.dispatchEvent(new Event('storageSync'));
  }
});

/* Export JSON file for sharing/backups */
function exportItems(){
  const items = loadItems();
  const blob = new Blob([JSON.stringify(items, null, 2)], {type:'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'dpsdiga-archive.json';
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

/* Copy short share string (base64 compressed) */
function copyShareText(){
  const items = loadItems();
  const text = JSON.stringify(items);
  try{
    const b64 = btoa(unescape(encodeURIComponent(text)));
    navigator.clipboard.writeText(b64).then(() => {
      alert('Archive share string copied to clipboard (paste into Import → Copy share text).');
    }, () => {
      prompt('Copy this share string:', b64);
    });
  }catch(e){
    console.error('Copy failed', e);
    prompt('Copy this share string:', text);
  }
}

/* Import from file (JSON) */
function handleImportFile(file){
  if(!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try{
      const parsed = JSON.parse(reader.result);
      if(!Array.isArray(parsed)) throw new Error('Invalid format');
      // Merge while avoiding id collisions
      const existing = loadItems();
      const ids = new Set(existing.map(i => i.id));
      const merged = existing.slice();
      parsed.forEach(it => {
        // ensure minimal fields
        if(!it.title || !it.description) return;
        const entry = {
          id: it.id && !ids.has(it.id) ? it.id : 'i' + (Date.now() + Math.floor(Math.random()*10000)),
          title: it.title,
          description: it.description,
          link: it.link || '',
          created: it.created || Date.now()
        };
        merged.unshift(entry);
      });
      saveItems(merged);
      renderItems();
      alert('Import complete.');
    }catch(err){
      alert('Failed to import: ' + err.message);
    }
  };
  reader.readAsText(file);
}

/* Import from copied share string (base64 or raw json) */
function importFromString(s){
  if(!s) return;
  try{
    let decoded = s;
    // try base64 decode
    try{
      decoded = decodeURIComponent(escape(atob(s)));
    }catch(e){}
    const parsed = JSON.parse(decoded);
    if(!Array.isArray(parsed)) throw new Error('Invalid data');
    // merge similar to file import
    const existing = loadItems();
    const ids = new Set(existing.map(i => i.id));
    const merged = existing.slice();
    parsed.forEach(it => {
      if(!it.title || !it.description) return;
      const entry = {
        id: it.id && !ids.has(it.id) ? it.id : 'i' + (Date.now() + Math.floor(Math.random()*10000)),
        title: it.title,
        description: it.description,
        link: it.link || '',
        created: it.created || Date.now()
      };
      merged.unshift(entry);
    });
    saveItems(merged);
    renderItems();
    alert('Import from share string complete.');
  }catch(err){
    alert('Failed to import share string: ' + err.message);
  }
}

/* Wire export/import UI */
if(exportBtn) exportBtn.addEventListener('click', exportItems);
if(copyBtn) copyBtn.addEventListener('click', copyShareText);
if(importFile) importFile.addEventListener('change', (e) => {
  const f = e.target.files[0];
  if(f) handleImportFile(f);
});

/* Allow user to paste a share string to import */
document.addEventListener('keydown', (e) => {
  if(e.ctrlKey && e.key.toLowerCase() === 'v' && (document.activeElement === document.body)){
    // no-op, but could be used for UX extensions
  }
});

/* Listen for 'storage' so multiple tabs stay in sync; also custom event for same-tab */
window.addEventListener('storage', (e) => {
  if(e.key === STORAGE_KEY) renderItems();
});
window.addEventListener('storageSync', () => renderItems());

/* Quick import prompt from UI: allow user to paste share string */
const copyImportButton = document.getElementById('copy-json');
if(copyImportButton){
  copyImportButton.addEventListener('dblclick', () => {
    const s = prompt('Paste share string or raw JSON to import:');
    if(s) importFromString(s.trim());
  });
  copyImportButton.title = 'Click to copy share string, double-click to paste a share string to import.';
}

/* Initial render on load */
document.addEventListener('DOMContentLoaded', renderItems);